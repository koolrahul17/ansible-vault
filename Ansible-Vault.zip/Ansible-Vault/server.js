const express = require("express");
var cors = require("cors");
const { Vault } = require('ansible-vault')

const app = express();
const port = 4500;

app.options("*", cors());

app.use(function (req, res, next) {
  res.setHeader(
    "Access-Control-Allow-Methods",
    "POST, PUT, OPTIONS, DELETE, GET"
  );
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.listen(port, function (error) {
    if (error) {
      console.log("Something went wrong");
    } else {
      console.log("server is listening on port " + port);
    }
  });
  
  //////////////////////////////////////////////////////////////////////////////////////////
  app.get("/", (req, res) => {
    res.end("Optiva -OBP Product Demo Mock Server");
  });

const fs = require('fs')
fileReadPromise = new Promise((resolve, reject)=>{
    fs.readFile('C:/Project/server/input.csv', 'utf8' , (err, data) => {
        if (err) {
          console.error(err)
          return
        }
        console.log(data)
        resolve(data)
      })

   
      
}).then((response)=>{
   
    const v = new Vault({ password: 'pa$$w0rd' })
     v.encrypt(response).then((responseEncrypted)=>{
         console.log(responseEncrypted)
    var b = String(responseEncrypted)
   
    fs.writeFile('C:/Project/server/input1.txt',b, function (err) {
        if (err) return console.log(err);
        console.log('Encrypted file Created');
        process.exit(0);
      });
    })
})